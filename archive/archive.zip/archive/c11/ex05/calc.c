/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   calc.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: isunwoo <isunwoo@student.42seoul.k>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/05/04 20:05:37 by isunwoo           #+#    #+#             */
/*   Updated: 2022/05/04 20:21:42 by isunwoo          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	plus(int a, int b)
{
	return (a + b);
}

int	minus(int a, int b)
{
	return (a - b);
}

int	divide(int a, int b)
{
	return (a / b);
}

int	modul(int a, int b)
{
	return (a % b);
}

int	multiply(int a, int b)
{
	return (a * b);
}
